#pragma once

extern int LoopInc(int curptr, int totallen);
extern int LoopDec(int curptr, int totallen);
extern int LLong2Int(long long data);

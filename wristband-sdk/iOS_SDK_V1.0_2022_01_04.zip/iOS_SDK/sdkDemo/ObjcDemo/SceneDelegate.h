//
//  SceneDelegate.h
//  ObjcDemo
//
//  Created by macos on 2021/11/29.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end


package com.example.ycblesdkdemo.model;

public class ConnectEvent {
}

package com.example.ycblesdkdemo.model;

public class BleModel {



}
